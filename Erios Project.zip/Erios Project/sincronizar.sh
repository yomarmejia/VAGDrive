#############################################################
#                     sincronizar.sh                        #
#############################################################

if [ $(id -u) != "0" ]; then
echo -e $rojo[x] Es esencial ser $azul [root] $rojo para ejecutar este setup [x]
echo " "
sleep 2s
exit 0
fi

mkdir ~/motion/gdrive/ > /dev/null 2>&1
cd ~/motion/gdrive/
carpeta=$(cat ~/gdrive.txt)
sudo gdrive sync content $carpeta
rm -rf ~/motion/gdrive/*

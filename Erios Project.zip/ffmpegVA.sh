#############################################################
#                       FfmpegVA.sh                         #
#############################################################

ffmpeg -f v4l2 -video_size 640x480 -framerate 30 -i /dev/video0 -f alsa -i default -f webm -cluster_size_limit 2M -cluster_time_limit 5100 -content_type video/webm -c:a libvorbis -b:a 96K -c:v libvpx -b:v 1.5M -crf 30 -g 150 -deadline good -threads 4 icecast://(cat ~/userIC.txt):(cat ~/passIC.txt)@localhost:8000/(cat ~/resIC.txt)
